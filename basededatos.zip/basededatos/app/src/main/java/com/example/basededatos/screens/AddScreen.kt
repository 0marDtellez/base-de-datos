package com.example.basededatos.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.basededatos.models.Alumnos
import com.example.basededatos.navigation.AppScreens
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreens(
    navController: NavController
){
    Scaffold(
        topBar = {
            TopAppBar() {
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                modifier = Modifier.size(32.dp),
                onClick = {
                    navController.navigate(route = AppScreens.Home.route)
                }
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription ="Agregar",
                    tint = Color.White
                )//fin Icon
            }//fin FloatingActionButton
        },//fin floatingActionButton
        floatingActionButtonPosition = FabPosition.End
    ) {
        BodyContent(navController)
    }
}
@Composable
fun BodyContent(
    navController:NavController
){
    var alumnoNombre by remember { mutableStateOf("") }
    var alumnoGrupo by remember { mutableStateOf("") }
    var alumnoCodigo by remember { mutableStateOf("") }
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 16.dp)
        ) {
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = alumnoNombre,
                onValueChange = {alumnoNombre=it},
                label = { Text("Nombre:")}
            )//fin Nombre
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = alumnoGrupo,
                onValueChange = {alumnoGrupo=it},
                label = { Text("Grupo:")}
            )//fin Grupo
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = alumnoCodigo,
                onValueChange = {alumnoCodigo=it},
                label = { Text("Codigo:")}
            )//fin Codigo
            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = {
                val alumnos=Alumnos(alumnoNombre,alumnoGrupo,alumnoCodigo.toInt())
                Firebase.firestore.collection("alumnos").add(alumnos)
                navController.navigate(route = AppScreens.Home.route)
            },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
            ){
                Text(text = "Add Alumno")
            }
        }
    }
}