package com.example.basededatos.navigation

sealed class AppScreens(val route:String){
    object Home:AppScreens(route = "AppAlumnos")
    object AddScreens:AppScreens(route = "AddScreens")
}