package com.example.basededatos.models

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class AlumnoViewModel: ViewModel() {
    private val _alumnos= mutableStateOf<List<Alumnos>>(emptyList())
    val alumnos:State<List<Alumnos>>
        get()=_alumnos
    private val query=Firebase.firestore.collection("alumnos")
    init {
        query.addSnapshotListener{ value,_->
            if (value!=null){
                _alumnos.value=value.toObjects()
            }
        }
    }
}