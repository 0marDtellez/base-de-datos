package com.example.basededatos.models

data class Alumnos(
    val nombre:String="",
    val curso:String="",
    val codigo:Int=0
){}//fin class
